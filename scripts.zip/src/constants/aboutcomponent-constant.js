export const about_links = [
    {
        id: 1,
        label: "Who We Are",
        link: "/about",
      },
      {
        id: 2,
        label: "Our Clients",
        link: "/clients",
      },
      {
        id: 3,
        label: "Our Team - #TheBFGPeople",
        link: "/team",
      },
      {
        id: 4,
        label: "Projects Executed",
        link: "/industry/projects",
      },
      {
        id: 5,
        label: "Awards & Recognition",
        link: "/award-recognition",
      },
      {
        id: 6,
        label: "Governance & Culture",
        link: "/governance-culture",
      },
    ]