export const card_links = [
    {
        id: 1,
        title: "Research & Analytics",
        logo: "/assets/research-data-analyst.jpg",
        link: "/solutions/research-analytics",
        content:
          "We provide startups, and SMEs with valuable insights and information that can inform business strategies, decision-making processes, and problem-solving efforts. We serve as an impartial partner for businesses in the process of gathering, analyzing and interpreting data in order to make informed decisions",
      },
      {
        id: 2,
        title: "Business Strategy & Operations",
        logo: "/assets/business.jpg",
        link: "/solutions/business-strategy",
        content:
          "Earn your business the ability to achieve desired goals through the development and implementation of plans and processes aimed at improving competitiveness. Through this service, we help startups and SMEs align their operations with their overall business objectives, streamline processes and optimise resources.",
      },
      {
        id: 3,
        title: "Training & Development",
        logo: "/assets/training-development-afr.jpg",
        link: "/solutions/training-development",
        content:
          "Improve job performance through employee training. Win the process of enhancing the skills, knowledge and abilities of employees to perform their jobs more  effectively. Through this solution, we help startups and SMEs improve their overall performance. ",
      },
      {
        id: 4,
        title: "Innovation & Technology",
        logo: "/assets/innovation-technology.jpg",
        link: "/solutions/information-technology",
        content:
          "Boost your business growth with digital tools. We take you through the process of designing and developing cutting-edge technology to enhance business effectiveness, ranging from web development and artificial intelligence to machine learning and block chain technology.  ",
      },
]