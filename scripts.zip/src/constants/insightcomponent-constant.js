export const insight_links = [
    {
        id: 1,
        label: "Newsroom",
        link: "/insight/news",
      },
      {
        id: 2,
        label: "Blogs",
        link: "/insight/blogs",
      },
      {
        id: 3,
        label: "Case Studies",
        link: "/insight/case-study",
      },
      {
        id: 4,
        label: "Careers",
        link: "/careers",
      },
     
    ]