import { Inter, Montserrat } from "next/font/google";
import "./globals.css";
import "./slider.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Messenger from "@/components/Messenger";
import FixedHeader from "@/components/FixedHeader";
import HeaderWrapper from "@/components/HeadWrapper";
import ClientBanner from "@/components/ClientBanner";
import ContactBanner from "@/components/ContactBanner";
import Script from "next/script";
import MainPage from "./MainPage";
import { Toaster } from "react-hot-toast";
import { Suspense } from "react";
import Loading from "@/components/loader/page";
import { ReduxProvider } from "@/redux/provider";
import MetaPixelTracker from "@/components/PixelTracker";
import { AuthProvider } from "@/context/authContext";
import { connectToMongoDB } from "./lib/db";

const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700"],
  variable: "--montserrat",
});
const inter = Inter({ subsets: ["latin"], variable: "--inter" });
// const poppins = Poppins({ subsets: ["latin"], variable: "--poppins"});

export const metadata = {
  title: "BFG Consults - Market Research, Software Development,  Strategy, & Training Services",
  description: "Management Consulting and Software Development Firm",
};

export default function RootLayout({ children }) {
  return children;
}
