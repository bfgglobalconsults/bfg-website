"use client";
import React, { useRef, useState } from "react";
import Image from "next/image";
import AnimatedItems from "@/components/information-technology/AnimatedItems";
import OfficeAddresses from "@/components/OfficeAddresses";
import CalendlyModal from "@/components/CalendlyModal";
import { motion, useInView } from "framer-motion";
import Link from "next/link";

const Page = () => {
  const benefitsRef = useRef(null);
  const isInView = useInView(benefitsRef, { once: true, amount: 0.2 });
  const [isCalendlyOpen, setIsCalendlyOpen] = useState(false);

  const ItSlides = [
    {
      title: "Software Designing & Development",
      content:
        "We manage the design & development of customised IT solutions that are tailored to the specific needs of an organisation & or business.",
    },
     {
      title: "Web/App Development",
      content:
        "We build responsive websites and user-friendly mobile apps tailored to your goals. From idea to launch, our team ensures seamless design, fast performance, and scalable functionality that delivers real results.",
    },
    {
      title: "IT Risk Assessment & Disaster Recovery",
      content:
        "This scope of service includes the development & implementation of plans & procedures that organisations can use to quickly & effectively recover from IT-related disruptions, such as natural disasters, power outages or cyber-attacks.",
    },
    {
      title: "Technical Support",
      content:
        "This scope of service involves assisting employees & other users of an organisations IT systems. This can include troubleshooting & resolving technical issues, as well as providing advice & guidance on the use of specific software or hardware.",
    },
    {
      title: "Cloud Services & Migration",
      content:
        "We assist organisations in migrating their IT infrastructure & applications to the cloud, ensuring scalability, security, cost-efficiency, enhanced performance, and business continuity.",
    },
    {
      title: "Cybersecurity",
      content:
        "This scope of service includes the implementation of security measures to protect an organisation’s IT systems & data from unauthorized access, breaches, and potential cyber threats. ",
    },
  ];

  return (
    <>
      <div className="mt-[0px] lg:mt-[150px] p-12">
        
          <span className="p-3 rounded-3xl bg-white border-2 border-[#E26015] font-semibold">
            Technology
          </span>
          <div className="flex flex-col lg:flex-row w-full gap-4 justify-between my-4">
            <h3 className="w-[100%] lg:w-[50%] text-[#333] font-bold text-4xl md:text-3xl lg:text-5xl">
              Technology & Software
            </h3>
            <p className="w-[100%] lg:w-[50%] text-[#E26015] my-2 text-lg lg:text-xl">
              Innovative solutions, secure technology, & unparalleled support for
              your business
            </p>
          </div>
        
      </div>
      <div className="px-12">
        <div className="relative w-full h-[200px] lg:h-[400px] bg-cover bg-center flex justify-center items-center">
          <Image
            src="/assets/it-banner.png"
            alt="top-banner"
            width={1200}
            height={400}
            className="w-full h-full object-cover rounded-3xl"
          />
        </div>
      </div>
      <div className="py-[1px] lg:py-[30px]">
        <div className="p-[40px]">
          <div className="w-full">
            <p className="text-lg text-[#656565] my-3">
              BFG Technology solutions is a specialised service deployed to help
              organisations optimize their use of technology to achieve their
              business objectives. Through this service, we provide a wide range
              of IT solutions, including, business web presence, cloud
              computing, software development, & cybersecurity. The service is
              delivered by our innovation & technology team, who are experts in
              their field & have the technical skills & knowledge to provide
              effective solutions. The goal of this service to clients is to
              improve their organisations efficiency, information security, &
              competitiveness by leveraging the latest technology.
            </p>
          </div>
        </div>
        <div className="w-full bg-[#041926] rounded-lg flex flex-col lg:flex-row gap-4 my-8">
          <motion.div 
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 2.6, duration: 1 }}
            className="w-[100%] lg:w-[50%] bg-[#041926] p-10 rounded-lg"
          >
            <div className="mb-4">
              <span className="p-3 rounded-3xl bg-white border-2 font-semibold">
                Focus Area
              </span>
            </div>
            <h3 className="text-white text-3xl font-semibold">
              Focus areas of our Technology & Software Consulting Services
            </h3>
            <p className="text-white my-4">
              Experience how our robust IT solutions & expert technical support
              deliver seamless technology integration, ensuring your systems
              reliability, security, & optimal performance from infrastructure
              to application.
            </p>
            <div className="w-full">
              <Image
                src="/assets/it-images.jpg"
                alt="it-image"
                width={1200}
                height={600}
                className="w-full rounded-lg"
              />
            </div>
          </motion.div>

          <motion.div 
            initial={{ x: 30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 2.7, duration: 1 }}
            className="w-[100%] bg-[#041926] p-4  lg:w-[50%] flex flex-col gap-10"
          >
            <AnimatedItems slides={ItSlides} />
          </motion.div>

          {/* <div className="w-[100%] flex gap-2">
              <div className="w-1/2 shadow-lg bg-[#f4f4f4] rounded-xl p-7">
                <h4 className="font-semibold text-xl text-[#333333]">
                  Software Designing & Development
                </h4>
                <p className="my-2 text-[#999]">
                 We manage the design & development of customised IT solutions that are tailored to the specific needs of an organisation & or business.
                </p>
              </div>
              <div className="w-1/2 shadow-lg bg-[#f4f4f4] rounded-xl p-7">
                <h4 className="font-semibold text-xl text-[#333333]">
                  IT Risk Assessment & Disaster Recovery
                </h4>
                <p className="my-2 text-[#999]">
                  This scope of service includes the development & implementation of plans & procedures that organisations can use to quickly & effectively recover from IT-related disruptions, such as natural disasters, power outages or cyber-attacks.
                </p>
              </div>{" "}
              <div className="w-full shadow-lg bg-[#f4f4f4] rounded-xl p-7">
                <h4 className="font-semibold text-xl text-[#333333]">
                  Technical Support
                </h4>
                <p className="my-2 text-[#999]">
                  This scope of service involves assisting employees & other users of an organisations IT systems. This can include troubleshooting & resolving technical issues, as well as providing advice & guidance on the use of specific software or hardware.
                </p>
              </div>{" "}
             
            </div> */}
        </div>

        <hr />
        <div className="p-[40px]">
          <div ref={benefitsRef} className="my-8">
            <span className="p-3 rounded-3xl bg-white border-2 border-[#E26015] font-semibold">
              Benefits
            </span>
            <div>
              <motion.h3 
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.8 }}
                className="text-[#333] text-3xl my-8 font-semibold"
              >
                Service Benefits
              </motion.h3>
              <p className="text-[#999] text-xl my-2">
                Unlock the full potential of your technology with our expert IT
                services, delivering seamless operations, enhanced performance,
                & sustainable solutions that drive lasting value & success.
              </p>
            </div>
            {/* <div className="w-full flex flex-col lg:flex-row gap-10">
              <div className="w-[100%] lg:w-[30%] h-[280px]">
                <Image
                  src={ServiceImage1}
                  alt="service-image1"
                  className="w-full h-full"
                />
              </div>
              <div className="w-[0%] h-[0%] lg:w-[70%] lg:h-[280px]">
                <Image
                  src={ServiceImage2}
                  alt="service-image2"
                  className="w-full h-full"
                />
              </div>
            </div> */}
            <div className="w-full flex flex-col lg:flex-row flex-wrap gap-10 my-6">
              <motion.div
                initial={{ x: -30, opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : { x: -30, opacity: 0 }}
                transition={{ duration: 0.8 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/improve-employee.jpg"
                    alt="employee-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Empowered Workforce Through Seamless Tech Support
                  </h4>
                  <p className="text-[#999]">
                   By providing reliable, fast, and user-friendly technology solutions, we ensure employees can focus on their work without tech-related frustrations. From responsive helpdesk support to intuitive tools and automation
                  </p>
                </div>
              </motion.div>
              {/* second item */}
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/data-security.jpg"
                    alt="data-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Enhanced Data Security
                  </h4>
                  <p className="text-[#999]">
                    IT services help organisations protect their IT systems &
                    data from unauthorized access & breaches by implementing
                    security measures such as firewalls, intrusion detection
                    systems, & regular security audits.
                  </p>
                </div>
              </motion.div>
              {/* third item */}
              <motion.div
                initial={{ x: -30, opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : { x: -30, opacity: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/data-mgt.jpg"
                    alt="datamgt-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Better Data Management
                  </h4>
                  <p className="text-[#999]">
                    It helps organisations manage & protect their data more
                    effectively by providing solutions such as data storage,
                    backup, & recovery.
                  </p>
                </div>
              </motion.div>
              {/* fourth item */}
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/flexibility-scalability.jpg"
                    alt="flex-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Increased Flexibility & Scalability
                  </h4>
                  <p className="text-[#999]">
                    Organisations adapt to changing business conditions & grow
                    their operations by providing scalable & flexible solutions
                    that can be easily modified & expanded as needed.
                  </p>{" "}
                </div>
              </motion.div>
              {/* fifth item */}
              <motion.div
                initial={{ x: -30, opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : { x: -30, opacity: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/expertise-resources.jpg"
                    alt="expertise-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Access to Expertise & Resources
                  </h4>
                  <p className="text-[#999]">
                    Our IT solutions provide organisations with access to
                    experts & resources that they might not have, such as
                    specialised software, & cybersecurity professionals.
                  </p>{" "}
                </div>
              </motion.div>
              {/* sixth item */}
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
                transition={{ duration: 0.8, delay: 1 }}
                whileHover={{ scale: 1.05 }}
                className="w-[100%] lg:w-[30%] flex flex-col items-center gap-7 p-4 lg:p-10 border rounded-2xl shadow-lg"
              >
                <div className="w-full h-[200px]">
                  <Image
                    src="/assets/innovation-development.jpg"
                    alt="innovation-img"
                    width={400}
                    height={200}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div className="w-[100%]">
                  <h4 className="text-xl text-[#333] font-semibold">
                    Accelerated Innovation and Development
                  </h4>
                  <p className="text-[#999]">
                    Drive rapid technological advancements through agile
                    development practices, fostering continuous improvement and
                    faster time-to-market for new solutions.
                  </p>{" "}
                </div>
              </motion.div>
            </div>
          </div>
          {/* portfolio */}
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
            className="py-[100px]"
          >
            <div className="flex flex-col items-center lg:flex-row gap-8">
              <div className="w-[100%] lg:w-[40%]">
                <Image
                  src="/assets/technology-portfolio.jpg"
                  alt="research"
                  width={600}
                  height={400}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="w-[100%] lg:w-[60%]">
                <span className="p-3 rounded-3xl bg-white border-2 border-[#E26015] font-semibold">
                  Portfolio
                </span>
                <h3 className="text-[#333] text-3xl my-8 font-semibold">
                  Empowering Businesses with Digital Transformation
                </h3>
                <p className="text-[#999] text-xl my-2">
                  Explore how BFG Global Consult empowers businesses to navigate
                  their digital journeys, transforming strategic goals into
                  actionable results. We showcase innovative solutions that
                  reflect our commitment to excellence, agility, and sustainable
                  growth.
                </p>
                                <Link href="/insight/case-study/technology">
                
                  <button className="bg-[#041926] py-2 px-6 rounded-xl hover:bg-[#E26015] flex gap-2 items-center">
                    <span className="text-white text-md font-semibold">
                      View Our Portfolio
                    </span>
                    <span>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        fill="rgba(255,255,255,1)"
                      >
                        <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"></path>
                      </svg>
                    </span>
                  </button>
                </Link>
              </div>
            </div>
          </motion.div>
          {/* service team */}
          <OfficeAddresses />
          <motion.div 
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
            className="w-[100%] lg:w-[60%] flex justify-center pt-14 my-14 mx-auto"
          >
            <div className="my-4">
              <p className="text-center text-2xl">
                Connect, collaborate, and innovate from anywhere as you drive
                digital transformation with our Technology & Software
                Development Solutions.
              </p>
              <div className="flex justify-center">
                <button 
                  onClick={() => setIsCalendlyOpen(true)}
                  className="bg-[#E26015] hover:bg-black my-4 text-white text-md lg:text-lg py-2 px-4 rounded-lg"
                >
                    Book a Quick Call
                  </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Calendly Modal */}
      <CalendlyModal
        isOpen={isCalendlyOpen}
        onClose={() => setIsCalendlyOpen(false)}
        calendlyUrl={process.env.NEXT_PUBLIC_CALENDLY_URL}
      />
    </>
  );
};

export default Page;
